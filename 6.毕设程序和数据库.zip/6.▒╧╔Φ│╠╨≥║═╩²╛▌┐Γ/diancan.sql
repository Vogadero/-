/*
 Navicat Premium Data Transfer

 Source Server         : 哥斯拉不说话
 Source Server Type    : MySQL
 Source Server Version : 50725
 Source Host           : localhost:3306
 Source Schema         : diancan

 Target Server Type    : MySQL
 Target Server Version : 50725
 File Encoding         : 65001

 Date: 12/06/2019 14:44:15
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for t_admin
-- ----------------------------
DROP TABLE IF EXISTS `t_admin`;
CREATE TABLE `t_admin`  (
  `userId` int(11) NOT NULL AUTO_INCREMENT,
  `userName` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `userPw` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`userId`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of t_admin
-- ----------------------------
INSERT INTO `t_admin` VALUES (1, 'admin', 'admin');

-- ----------------------------
-- Table structure for t_catelog
-- ----------------------------
DROP TABLE IF EXISTS `t_catelog`;
CREATE TABLE `t_catelog`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `del` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 50 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of t_catelog
-- ----------------------------
INSERT INTO `t_catelog` VALUES (39, '热菜', 'no');
INSERT INTO `t_catelog` VALUES (46, '凉菜', 'no');
INSERT INTO `t_catelog` VALUES (47, '饮品', 'no');
INSERT INTO `t_catelog` VALUES (48, '面食', 'no');
INSERT INTO `t_catelog` VALUES (49, '汤菜', 'no');

-- ----------------------------
-- Table structure for t_goods
-- ----------------------------
DROP TABLE IF EXISTS `t_goods`;
CREATE TABLE `t_goods`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `catelog_id` int(11) NULL DEFAULT NULL,
  `bianhao` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `mingcheng` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `jieshao` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `fujian` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `shichangjia` int(11) NULL DEFAULT NULL,
  `del` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `qiye_id` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 72 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of t_goods
-- ----------------------------
INSERT INTO `t_goods` VALUES (62, 46, '1001', '凉拌牛肉', '凉拌牛肉一份，重量500G', '/upload/1542376504158.gif', 25, 'no', 4);
INSERT INTO `t_goods` VALUES (63, 46, '1002', '拌烧肉', '拌烧肉一份，重量500G', '/upload/1542376589414.gif', 20, 'no', 3);
INSERT INTO `t_goods` VALUES (64, 39, '2001', '西红柿鸡蛋', '西红柿鸡蛋一盘，重量500G', '/upload/1542376630550.jpg', 15, 'no', 4);
INSERT INTO `t_goods` VALUES (65, 48, '3001', '手工水饺', '手工水饺一份，重量500G', '/upload/1542376845202.jpg', 20, 'no', 3);
INSERT INTO `t_goods` VALUES (66, 39, '6001', '韭菜鸡蛋', '韭菜鸡蛋一份', '/upload/1559376319755.jpg', 10, 'no', 3);
INSERT INTO `t_goods` VALUES (67, 46, '5001', '凉拌菠菜', '菠菜甘甜爽口，1000g', '/upload/1559915237833.jpg', 8, 'no', 5);
INSERT INTO `t_goods` VALUES (68, 47, '6001', '一点点', '波霸奶茶，奶茶中的奶茶', '/upload/1559915389205.jpg', 14, 'no', 6);
INSERT INTO `t_goods` VALUES (69, 47, '6002', '仙草奶茶', '喝过再来！', '/upload/1559915465505.jpg', 18, 'no', 6);
INSERT INTO `t_goods` VALUES (70, 46, '7001', '鸭脖', '周黑鸭！', '/upload/1559915596409.jpg', 8, 'no', 7);
INSERT INTO `t_goods` VALUES (71, 46, '7002', '鸭头', '史前鸭头', '/upload/1559915649781.jpg', 12, 'no', 7);

-- ----------------------------
-- Table structure for t_liuyan
-- ----------------------------
DROP TABLE IF EXISTS `t_liuyan`;
CREATE TABLE `t_liuyan`  (
  `ID` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `title` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `content` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `shijian` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `User_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of t_liuyan
-- ----------------------------
INSERT INTO `t_liuyan` VALUES ('1', '好评', '五星好评', '2018-11-16 09:39:17', NULL);

-- ----------------------------
-- Table structure for t_order
-- ----------------------------
DROP TABLE IF EXISTS `t_order`;
CREATE TABLE `t_order`  (
  `id` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `bianhao` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `shijian` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `zhuangtai` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `songhuodizhi` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `fukuanfangshi` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `jine` int(11) NULL DEFAULT NULL,
  `user_id` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of t_order
-- ----------------------------
INSERT INTO `t_order` VALUES ('1542375557912', '20181116093917', '2018-11-16 09:39:17', 'yes', '1', '银行付款', 100, '1542375422795');
INSERT INTO `t_order` VALUES ('1542377017308', '20181116100337', '2018-11-16 10:03:37', 'no', '北四路21号', '货到付款', 80, '1542375422795');
INSERT INTO `t_order` VALUES ('1558787404601', '20190525083004', '2019-05-25 08:30:04', 'no', '北京东城朝阳', '货到付款', 22, '1558777084238');
INSERT INTO `t_order` VALUES ('1560240062561', '20190611040102', '2019-06-11 04:01:02', 'no', '北京东城朝阳', '银行付款', 25, '4');

-- ----------------------------
-- Table structure for t_orderitem
-- ----------------------------
DROP TABLE IF EXISTS `t_orderitem`;
CREATE TABLE `t_orderitem`  (
  `id` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `order_id` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `goods_id` int(11) NULL DEFAULT NULL,
  `goods_quantity` int(11) NULL DEFAULT NULL
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of t_orderitem
-- ----------------------------
INSERT INTO `t_orderitem` VALUES ('1542377017428', '1542377017308', 64, 1);
INSERT INTO `t_orderitem` VALUES ('1542377017595', '1542377017308', 65, 1);
INSERT INTO `t_orderitem` VALUES ('1542377017690', '1542377017308', 63, 1);
INSERT INTO `t_orderitem` VALUES ('1542377017773', '1542377017308', 62, 1);
INSERT INTO `t_orderitem` VALUES ('1560240062729', '1560240062561', 62, 1);

-- ----------------------------
-- Table structure for t_qishou
-- ----------------------------
DROP TABLE IF EXISTS `t_qishou`;
CREATE TABLE `t_qishou`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `loginname` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `loginpw` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `name` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `tel` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of t_qishou
-- ----------------------------
INSERT INTO `t_qishou` VALUES (1, '哥斯拉不说话3', '123456', '贺瑞斌', '15732651142');
INSERT INTO `t_qishou` VALUES (2, '哥斯拉不说话33', '123456', '席陇伟', '15732651144');
INSERT INTO `t_qishou` VALUES (3, '哥斯拉不说话333', '123456', '袁皓', '15732651113');
INSERT INTO `t_qishou` VALUES (4, '阿基米德', '123456', '倪洁洲', '15732651100');
INSERT INTO `t_qishou` VALUES (5, '爱因斯坦', '123456', '米恩涛', '15732654444');

-- ----------------------------
-- Table structure for t_qiye
-- ----------------------------
DROP TABLE IF EXISTS `t_qiye`;
CREATE TABLE `t_qiye`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `loginname` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `loginpw` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `name` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `tel` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `danwei` varchar(252) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `dizhi` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 8 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of t_qiye
-- ----------------------------
INSERT INTO `t_qiye` VALUES (3, '我是商家3', '123456', '贺瑞', '15732651144', '北京南站', '北京南锣鼓巷');
INSERT INTO `t_qiye` VALUES (4, '我是商家4', '123456', '贺', '15732651142', '北京西站', '北京南锣鼓');
INSERT INTO `t_qiye` VALUES (5, '我是商家5', '123456', '何锐步', '15732665555', '北京北站', '北京什刹海');
INSERT INTO `t_qiye` VALUES (6, '我是商家6', '123456', '张天润', '15766665657', '河北廊坊', '河北三河市');
INSERT INTO `t_qiye` VALUES (7, '我是商家7', '123456', '于小雅', '15744676545', '河北燕郊', '河北燕郊');

-- ----------------------------
-- Table structure for t_user
-- ----------------------------
DROP TABLE IF EXISTS `t_user`;
CREATE TABLE `t_user`  (
  `id` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `loginname` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `loginpw` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `sex` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `age` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `address` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `tel` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `email` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `qq` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `del` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of t_user
-- ----------------------------
INSERT INTO `t_user` VALUES ('1', 'chenming', '123456', '陈明', '男', '22', '山东济南大明路二号', '15166862185', 'chenming@126.com', '15166862154', 'no');
INSERT INTO `t_user` VALUES ('2', 'zhangli', '123456', '张丽', '男', '22', '山东大明路二号', '15166862185', 'zhangli@126.com', '15166862152', 'no');
INSERT INTO `t_user` VALUES ('3', 'yanxiezi', '123456', '严谢梓', '男', '18', '北京东城朝阳', '15732651140', '994010222@qq.com', '994019222', 'no');
INSERT INTO `t_user` VALUES ('4', 'lisi', '123456', '李四', '女', '35', '河北燕郊', '16755463453', '77635478@qq.com', '77635478', 'no');
INSERT INTO `t_user` VALUES ('5', 'yuxiaoya', '123456', '于小雅', '女', '18', '北京朝阳', '15744653535', 'yuxiaoya@163.com', '667524168', 'no');

SET FOREIGN_KEY_CHECKS = 1;
