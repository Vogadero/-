package com.action;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.directwebremoting.WebContext;
import org.directwebremoting.WebContextFactory;

import com.dao.DB;
import com.orm.TAdmin;
import com.orm.Tuser;
import com.orm.Tqishou;
public class qishou_servlet extends HttpServlet
{
	public void service(HttpServletRequest req,HttpServletResponse res)throws ServletException, IOException 
	{
        String type=req.getParameter("type");
		
		
		if(type.endsWith("qishouReg"))
		{
			qishouReg(req, res);
		}
		if(type.endsWith("qishouMana"))
		{
			qishouMana(req, res);
		}
		if(type.endsWith("qishouUpdate"))
		{
			qishouUpdate(req, res);
		}
		if(type.endsWith("qishouDel"))
		{
			qishouDel(req, res);
		}
	}
	public void qishouReg(HttpServletRequest req,HttpServletResponse res)
	{

		String loginname=req.getParameter("loginname");
		String loginpw=req.getParameter("loginpw");
		String name=req.getParameter("name");
		String tel=req.getParameter("tel");


		
		String sql="insert into t_qishou(loginname,loginpw,name,tel) values(?,?,?,?)";
		Object[] params={loginname,loginpw,name,tel};
		DB mydb=new DB();
		mydb.doPstm(sql, params);
		mydb.closed();
		req.setAttribute("message", "注册成功");
		req.setAttribute("path", "qiantai/default.jsp");
		
        String targetURL = "/common/success.jsp";
		dispatch(targetURL, req, res);
	}
	
	
	
	public void userLogout(HttpServletRequest req,HttpServletResponse res)
	{
		req.getSession().setAttribute("user", null);
		String targetURL = "/qiantai/default.jsp";
		dispatch(targetURL, req, res);		
	}
	
	public void qishouUpdate(HttpServletRequest req,HttpServletResponse res)
	{
		String id=req.getParameter("id");
		String loginname=req.getParameter("loginname");
		String name=req.getParameter("name");
		String tel=req.getParameter("tel");

		
		String sql="update t_qishou set loginname=?,name=?,tel=? where id=?";
		Object[] params={loginname,name,tel,id};
		DB mydb=new DB();
		mydb.doPstm(sql, params);
		mydb.closed();
		

		
		
		req.setAttribute("message", "修改成功，重新登录后生效");
		req.setAttribute("path", "admin/userinfo/qiyeEdit.jsp");
		
        String targetURL = "/common/success.jsp";
		dispatch(targetURL, req, res);
	}
	
	
	public void qishouDel(HttpServletRequest req,HttpServletResponse res)
	{
		String id=req.getParameter("id");
		
		String sql="delete from t_qishou where id=?";
		Object[] params={id};
		DB mydb=new DB();
		mydb.doPstm(sql, params);
		mydb.closed();
		
		req.setAttribute("message", "操作成功");
		req.setAttribute("path", "qishou?type=qishouMana");
		
        String targetURL = "/common/success.jsp";
		dispatch(targetURL, req, res);
	}

	public void qishouMana(HttpServletRequest req,HttpServletResponse res) throws ServletException, IOException
	{
		List qishouList=new ArrayList();
		String sql="select * from t_qishou";
		Object[] params={};
		DB mydb=new DB();
		try
		{
			mydb.doPstm(sql, params);
			ResultSet rs=mydb.getRs();
			while(rs.next())
			{
				Tqishou qishou=new Tqishou();
				
				qishou.setId(rs.getInt("id"));
				qishou.setLoginname(rs.getString("loginname"));
				qishou.setLoginpw(rs.getString("loginpw"));
				qishou.setName(rs.getString("name"));
				qishou.setTel(rs.getString("tel"));
			    qishouList.add(qishou);
		    }
			rs.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		mydb.closed();
		
		req.setAttribute("qishouList", qishouList);
		req.getRequestDispatcher("xitong/qishou/qishouMana.jsp").forward(req, res);
	}
	
	public void dispatch(String targetURI,HttpServletRequest request,HttpServletResponse response) 
	{
		RequestDispatcher dispatch = getServletContext().getRequestDispatcher(targetURI);
		try 
		{
		    dispatch.forward(request, response);
		    return;
		} 
		catch (ServletException e) 
		{
                    e.printStackTrace();
		} 
		catch (IOException e) 
		{
			
		    e.printStackTrace();
		}
	}
	public void init(ServletConfig config) throws ServletException 
	{
		super.init(config);
	}
	
	public void destroy() 
	{
		
	}
}
