package com.action;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.directwebremoting.WebContext;
import org.directwebremoting.WebContextFactory;

import com.dao.DB;
import com.orm.TAdmin;
import com.orm.Tuser;
import com.orm.Tqiye;
public class qiye_servlet extends HttpServlet
{
	public void service(HttpServletRequest req,HttpServletResponse res)throws ServletException, IOException 
	{
        String type=req.getParameter("type");
		
		
		if(type.endsWith("qiyeReg"))
		{
			qiyeReg(req, res);
		}
		if(type.endsWith("qiyeMana"))
		{
			qiyeMana(req, res);
		}
		if(type.endsWith("qiyeUpdate"))
		{
			qiyeUpdate(req, res);
		}
		if(type.endsWith("qiyeDel"))
		{
			qiyeDel(req, res);
		}
	}
	public void qiyeReg(HttpServletRequest req,HttpServletResponse res)
	{

		String loginname=req.getParameter("loginname");
		String loginpw=req.getParameter("loginpw");
		String name=req.getParameter("name");
		String tel=req.getParameter("tel");
		String dizhi=req.getParameter("dizhi");
		String danwei=req.getParameter("danwei");

		
		String sql="insert into t_qiye(loginname,loginpw,name,tel,dizhi,danwei) values(?,?,?,?,?,?)";
		Object[] params={loginname,loginpw,name,tel,dizhi,danwei};
		DB mydb=new DB();
		mydb.doPstm(sql, params);
		mydb.closed();
		req.setAttribute("message", "注册成功");
		req.setAttribute("path", "qiantai/default.jsp");
		
        String targetURL = "/common/success.jsp";
		dispatch(targetURL, req, res);
	}
	
	
	
	public void userLogout(HttpServletRequest req,HttpServletResponse res)
	{
		req.getSession().setAttribute("user", null);
		String targetURL = "/qiantai/default.jsp";
		dispatch(targetURL, req, res);		
	}
	
	public void qiyeUpdate(HttpServletRequest req,HttpServletResponse res)
	{
		String id=req.getParameter("id");
		String loginname=req.getParameter("loginname");
		String name=req.getParameter("name");
		String tel=req.getParameter("tel");
		String dizhi=req.getParameter("dizhi");
		String danwei=req.getParameter("danwei");
		
		String sql="update t_qiye set loginname=?,name=?,tel=?,dizhi=?,danwei=? where id=?";
		Object[] params={loginname,name,tel,dizhi,danwei,id};
		DB mydb=new DB();
		mydb.doPstm(sql, params);
		mydb.closed();
		

		
		
		req.setAttribute("message", "修改成功，重新登录后生效");
		req.setAttribute("path", "admin/userinfo/qiyeEdit.jsp");
		
        String targetURL = "/common/success.jsp";
		dispatch(targetURL, req, res);
	}
	
	
	public void qiyeDel(HttpServletRequest req,HttpServletResponse res)
	{
		String id=req.getParameter("id");
		
		String sql="delete from t_qiye where id=?";
		Object[] params={id};
		DB mydb=new DB();
		mydb.doPstm(sql, params);
		mydb.closed();
		
		req.setAttribute("message", "操作成功");
		req.setAttribute("path", "qiye?type=qiyeMana");
		
        String targetURL = "/common/success.jsp";
		dispatch(targetURL, req, res);
	}

	public void qiyeMana(HttpServletRequest req,HttpServletResponse res) throws ServletException, IOException
	{
		List qiyeList=new ArrayList();
		String sql="select * from t_qiye";
		Object[] params={};
		DB mydb=new DB();
		try
		{
			mydb.doPstm(sql, params);
			ResultSet rs=mydb.getRs();
			while(rs.next())
			{
				Tqiye qiye=new Tqiye();
				
				qiye.setId(rs.getInt("id"));
				qiye.setLoginname(rs.getString("loginname"));
				qiye.setLoginpw(rs.getString("loginpw"));
				qiye.setName(rs.getString("name"));
				qiye.setTel(rs.getString("tel"));
				qiye.setDanwei(rs.getString("danwei"));
				qiye.setDizhi(rs.getString("dizhi"));
				qiyeList.add(qiye);
		    }
			rs.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		mydb.closed();
		
		req.setAttribute("qiyeList", qiyeList);
		req.getRequestDispatcher("xitong/qiye/qiyeMana.jsp").forward(req, res);
	}
	
	public void dispatch(String targetURI,HttpServletRequest request,HttpServletResponse response) 
	{
		RequestDispatcher dispatch = getServletContext().getRequestDispatcher(targetURI);
		try 
		{
		    dispatch.forward(request, response);
		    return;
		} 
		catch (ServletException e) 
		{
                    e.printStackTrace();
		} 
		catch (IOException e) 
		{
			
		    e.printStackTrace();
		}
	}
	public void init(ServletConfig config) throws ServletException 
	{
		super.init(config);
	}
	
	public void destroy() 
	{
		
	}
}
