package com.orm;

public class TorderItem
{
	private String id;
	private String order_id;
	private int goods_id;
	private int goods_quantity;
	private String tel;
	private String danwei;
	private String dizhi;
	private String mingcheng;
	private int shichangjia;
	
	private Tgoods goods;//����û�С��Լ��ӵ�
	
	public int getShichangjia()
	{
		return shichangjia;
	}
	public void setShichangjia(int shichangjia)
	{
		this.shichangjia = shichangjia;
	}
	public String getDanwei()
	{
		return danwei;
	}
	public void setDanwei(String danwei)
	{
		this.danwei = danwei;
	}
	
	public String getDizhi()
	{
		return dizhi;
	}
	public void setDizhi(String dizhi)
	{
		this.dizhi = dizhi;
	}
	public String getTel()
	{
		return tel;
	}
	public void setTel(String tel)
	{
		this.tel = tel;
	}
	
	public String getMingcheng()
	{
		return mingcheng;
	}
	public void setMingcheng(String mingcheng)
	{
		this.mingcheng = mingcheng;
	}

	
	public int getGoods_id()
	{
		return goods_id;
	}
	public void setGoods_id(int goods_id)
	{
		this.goods_id = goods_id;
	}
	public int getGoods_quantity()
	{
		return goods_quantity;
	}
	public void setGoods_quantity(int goods_quantity)
	{
		this.goods_quantity = goods_quantity;
	}
	
	public String getId()
	{
		return id;
	}
	public void setId(String id)
	{
		this.id = id;
	}
	public String getOrder_id()
	{
		return order_id;
	}
	public void setOrder_id(String order_id)
	{
		this.order_id = order_id;
	}
	public Tgoods getGoods()
	{
		return goods;
	}
	public void setGoods(Tgoods goods)
	{
		this.goods = goods;
	}
	
	

}
