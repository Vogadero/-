package com.orm;

public class Tgoods 
{
	private int id;
	private int catelog_id;
	private String bianhao;
	
	private String mingcheng;
	private String jieshao;
	private String fujian;
	
	private int shichangjia;
	private String del;
	private String name;
	
	
	public String getName()
	{
		return name;
	}
	public void setName(String name)
	{
		this.name = name;
	}
	public String getBianhao()
	{
		return bianhao;
	}
	public void setBianhao(String bianhao)
	{
		this.bianhao = bianhao;
	}
	public int getCatelog_id()
	{
		return catelog_id;
	}
	public void setCatelog_id(int catelog_id)
	{
		this.catelog_id = catelog_id;
	}
	public String getDel()
	{
		return del;
	}
	public void setDel(String del)
	{
		this.del = del;
	}
	public String getFujian()
	{
		return fujian;
	}
	public void setFujian(String fujian)
	{
		this.fujian = fujian;
	}
	public int getId()
	{
		return id;
	}
	public void setId(int id)
	{
		this.id = id;
	}
	public String getJieshao()
	{
		return jieshao;
	}
	public void setJieshao(String jieshao)
	{
		this.jieshao = jieshao;
	}
	public String getMingcheng()
	{
		return mingcheng;
	}
	public void setMingcheng(String mingcheng)
	{
		this.mingcheng = mingcheng;
	}

	public int getShichangjia()
	{
		return shichangjia;
	}
	public void setShichangjia(int shichangjia)
	{
		this.shichangjia = shichangjia;
	}

	
}
